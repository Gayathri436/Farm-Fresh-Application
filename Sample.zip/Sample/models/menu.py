# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations

# ----------------------------------------------------------------------------------------------------------------------
# this is the main application menu add/remove items as required
# ----------------------------------------------------------------------------------------------------------------------
response.logo=A(B('web' ,SPAN(2) ,'py'),XML('&trade;&nbsp:'),
                _class="navbar-brand" ,_href="http://www.web2py.com/",
                _id="web2py-logo")

                
response.menu = [
    (T('Home'), False, URL('products', 'view'), [])
]
DEVELOPMENT_MENU =  True


# ----------------------------------------------------------------------------------------------------------------------
# provide shortcuts for development. you can remove everything below in production
# ---------------------------------------------------------------------------------------------------------------------- 
def _():
    app = request.application
    ctr= request.controller
    response.menu += [
        (T('Post'), False, URL('products', 'post')),
        (T('Profile'), False,URL('profile', 'save'))
    ]
